<?php
$mysql_host= 'localhost';
$mysql_user= 'root';
$mysql_password='';
$db='user_database';
$db=mysqli_connect($mysql_host,$mysql_user,$mysql_password,'user_database');


?>