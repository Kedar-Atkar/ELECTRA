
<form method="GET" action="addtocart.php?">
	  <input type="submit" value="add to cart" >
		</form>