<?php
?>
<h1 align="center">TE IT-B</h1>
<h2 align="center">IP Project</h2>
<h3 align="center">Group members</h3>
<p style="width:25%;float:left;">Swastik Sonkusare - 16101B0051</p>
<p style="width:25%;float:left;">Mohit Singhvi - 16101B0056</p>
<p style="width:25%;float:left;">Kedar Atkar - 16101B0063</p>
<a href="home.php" align="center" >Electra home</a>
